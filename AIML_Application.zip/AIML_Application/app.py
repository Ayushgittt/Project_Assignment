import streamlit as st
import pandas as pd
import pickle

# Load the dataset
st.title("Mushroom Classification App 🍄")
st.write("Upload your mushroom data to classify it.")

# Load dataset
df = pd.read_csv("mushrooms.csv")

# Load pre-trained model (assume you trained and saved it as model.pkl)
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

# User input
input_data = st.text_input("Enter feature values (comma-separated):")

if st.button("Predict"):
    try:
        input_values = [float(i) for i in input_data.split(",")]
        prediction = model.predict([input_values])
        st.write(f"Prediction: {prediction[0]}")
    except Exception as e:
        st.write(f"Error: {e}")
